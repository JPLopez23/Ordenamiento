public interface iSort<T extends Comparable<T>> {
    T[] sort(T[] array);
}
